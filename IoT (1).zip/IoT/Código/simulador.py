import requests
import random
import time

def send_temperature_data():
    url = 'http://localhost:5001/temperature'
    while True:
        # Gerar temperatura aleatória entre -10 e 10 graus Celsius
        temperature = random.uniform(-10, 10)
        response = requests.post(url, json={'temperature': temperature})
        print(f'Temperature sent: {temperature}°C, Response: {response.text}')
        time.sleep(5)  # Espera 5 segundos antes de enviar o próximo dado

if __name__ == '__main__':
    send_temperature_data()
