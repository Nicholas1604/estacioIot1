from flask import Flask, request, jsonify, render_template
import os

app = Flask(__name__)

# Caminho para o arquivo onde as temperaturas serão armazenadas
TEMPERATURE_FILE = 'temperatures.txt'

# Lista para armazenar os produtos e suas temperaturas ideais
products = [
    {"name": "Molho de Tomate", "ideal_temperature": 2},
    {"name": "Queijo Mozzarella", "ideal_temperature": 1},
    {"name": "Massa de Pizza", "ideal_temperature": 4},
    {"name": "Carne", "ideal_temperature": -2},
    {"name": "Pepperoni", "ideal_temperature": -2},
    {"name": "Azeitonas", "ideal_temperature": 3},
    {"name": "Cebola", "ideal_temperature": 3},
    {"name": "Pimentão", "ideal_temperature": 3}
]

@app.route('/temperature', methods=['POST'])
def receive_temperature():
    data = request.get_json()
    current_temperature = data['temperature']

    # Armazenar a temperatura recebida no arquivo
    with open(TEMPERATURE_FILE, 'a') as file:
        file.write(f"{current_temperature}\n")

    return jsonify({'status': 'success', 'message': 'Temperature received'})

@app.route('/')
def dashboard():
    # Ler temperaturas do arquivo
    temperatures = []
    if os.path.exists(TEMPERATURE_FILE):
        with open(TEMPERATURE_FILE, 'r') as file:
            temperatures = [float(line.strip()) for line in file if line.strip()]

    # Processar o status de cada produto com base na última temperatura recebida
    product_status = []
    if temperatures:
        recent_temp = temperatures[-1]
        for product in products:
            if product['ideal_temperature'] == 0:
                # Defina um status especial ou ignore o cálculo se a temperatura ideal é zero
                status = 'Rever Definição de Temperatura Ideal'
            else:
                product_temp_ratio = recent_temp / product['ideal_temperature']
                if product_temp_ratio < 0.5:
                    status = 'Perigo'
                elif product_temp_ratio < 0.8:
                    status = 'Atenção'
                elif product_temp_ratio <= 1.1:
                    status = 'Normal'
                else:
                    status = 'Normal'  # Considera temperaturas acima de 110% como normais
            product_status.append({'name': product['name'], 'ideal_temperature': product['ideal_temperature'], 'status': status})

    return render_template('dashboard.html', product_status=product_status, temperatures=temperatures[-10:], latest_temperature=temperatures[-1] if temperatures else 'No data')

if __name__ == '__main__':
    app.run(debug=True, port=5001)
